"use client";

import { useState } from "react";
import {
  Users,
  ShieldCheck,
  Plus,
  X,
  Bell,
  MessageCircle,
  Phone,
  Heart,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { MOCK_CONTACTS, MOCK_ALERT_LOGS, type Contact } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export function ContactsContent() {
  const [contacts, setContacts] = useState<Contact[]>(MOCK_CONTACTS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");

  const trustedContacts = contacts.filter((c) => c.isTrusted);
  const allContacts = contacts;

  const toggleTrusted = (id: string) => {
    setContacts((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, isTrusted: !c.isTrusted } : c
      )
    );
  };

  const handleAddContact = () => {
    if (!newName.trim()) return;
    const initials = newName
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
    const newContact: Contact = {
      id: Date.now().toString(),
      name: newName.trim(),
      initials,
      phone: newPhone.trim() || "+1 555-0000",
      platform: "sms",
      isTrusted: true,
      isRestricted: false,
    };
    setContacts((prev) => [...prev, newContact]);
    setNewName("");
    setNewPhone("");
    setDialogOpen(false);
  };

  const removeContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">
            Trusted Contacts
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage who gets notified and view alert history.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="h-4 w-4" />
              Add Contact
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-foreground">Add Trusted Contact</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col gap-3 mt-2">
              <Input
                placeholder="Full name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
              <Input
                placeholder="Phone number (optional)"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
              />
              <Button
                onClick={handleAddContact}
                disabled={!newName.trim()}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Add to Trusted Contacts
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="trusted" className="space-y-4">
        <TabsList className="bg-muted">
          <TabsTrigger value="trusted" className="gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5" />
            Trusted ({trustedContacts.length})
          </TabsTrigger>
          <TabsTrigger value="all" className="gap-1.5">
            <Users className="h-3.5 w-3.5" />
            All ({allContacts.length})
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-1.5">
            <Bell className="h-3.5 w-3.5" />
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trusted">
          <div className="grid gap-3 md:grid-cols-2">
            {trustedContacts.map((contact) => (
              <ContactCard
                key={contact.id}
                contact={contact}
                onToggleTrusted={toggleTrusted}
                onRemove={removeContact}
              />
            ))}
            {trustedContacts.length === 0 && (
              <div className="col-span-full text-center py-12">
                <ShieldCheck className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  No trusted contacts yet. Add someone who can support you.
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="all">
          <div className="grid gap-3 md:grid-cols-2">
            {allContacts.map((contact) => (
              <ContactCard
                key={contact.id}
                contact={contact}
                onToggleTrusted={toggleTrusted}
                onRemove={removeContact}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-semibold text-card-foreground">
                Alert History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-3">
                {MOCK_ALERT_LOGS.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-start gap-3 rounded-lg bg-muted/40 p-3"
                  >
                    <div
                      className={cn(
                        "rounded-full p-1.5 shrink-0",
                        log.type === "stress_alert" && "bg-destructive/10 text-destructive",
                        log.type === "calm_message" && "bg-primary/10 text-primary",
                        log.type === "quick_call" && "bg-accent/10 text-accent"
                      )}
                    >
                      {log.type === "stress_alert" && <Bell className="h-3.5 w-3.5" />}
                      {log.type === "calm_message" && <Heart className="h-3.5 w-3.5" />}
                      {log.type === "quick_call" && <Phone className="h-3.5 w-3.5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-semibold text-foreground">
                          {log.contactName}
                        </p>
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-[10px] h-4 px-1.5 border-transparent",
                            log.type === "stress_alert" && "bg-destructive/10 text-destructive",
                            log.type === "calm_message" && "bg-primary/10 text-primary",
                            log.type === "quick_call" && "bg-accent/10 text-accent"
                          )}
                        >
                          {log.type.replace("_", " ")}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground ml-auto">
                          {log.timestamp}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {log.message}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ContactCard({
  contact,
  onToggleTrusted,
  onRemove,
}: {
  contact: Contact;
  onToggleTrusted: (id: string) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="pt-4 pb-4 px-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarFallback
              className={cn(
                "font-semibold text-sm",
                contact.isTrusted
                  ? "bg-primary/10 text-primary"
                  : "bg-secondary text-secondary-foreground"
              )}
            >
              {contact.initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-foreground truncate">{contact.name}</p>
              {contact.isTrusted && (
                <ShieldCheck className="h-3.5 w-3.5 text-primary shrink-0" />
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {contact.phone} &middot;{" "}
              <span className="capitalize">{contact.platform}</span>
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggleTrusted(contact.id)}
              className={cn(
                "h-7 text-[10px] px-2",
                contact.isTrusted
                  ? "text-primary hover:text-primary/80 hover:bg-primary/10"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {contact.isTrusted ? "Trusted" : "Add Trust"}
            </Button>
            <button
              onClick={() => onRemove(contact.id)}
              className="text-muted-foreground hover:text-destructive transition-colors p-1"
              aria-label={`Remove ${contact.name}`}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

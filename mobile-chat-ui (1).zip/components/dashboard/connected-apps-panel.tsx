"use client";

import { useState, useCallback } from "react";
import {
  Link2,
  MessageCircle,
  Camera,
  Smartphone,
  Send,
  Hash,
  Shield,
  Check,
  Loader2,
  Unlink,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { MOCK_APPS, type ConnectedApp } from "@/lib/mock-data";

function getAppIcon(name: string) {
  switch (name) {
    case "WhatsApp":
      return <MessageCircle className="h-5 w-5" />;
    case "Instagram":
      return <Camera className="h-5 w-5" />;
    case "Messages":
      return <Smartphone className="h-5 w-5" />;
    case "Telegram":
      return <Send className="h-5 w-5" />;
    case "Slack":
      return <Hash className="h-5 w-5" />;
    case "Signal":
      return <Shield className="h-5 w-5" />;
    default:
      return <MessageCircle className="h-5 w-5" />;
  }
}

export function ConnectedAppsPanel() {
  const [apps, setApps] = useState<ConnectedApp[]>(MOCK_APPS);
  const [connectingId, setConnectingId] = useState<string | null>(null);
  const [dialogApp, setDialogApp] = useState<ConnectedApp | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const connectedCount = apps.filter((a) => a.connected).length;
  const visibleApps = expanded ? apps : apps.slice(0, 4);

  const handleConnect = useCallback((app: ConnectedApp) => {
    if (app.connected) {
      // Disconnect immediately
      setApps((prev) =>
        prev.map((a) => (a.id === app.id ? { ...a, connected: false } : a))
      );
      return;
    }
    // Show permission dialog
    setDialogApp(app);
    setDialogOpen(true);
  }, []);

  const confirmConnect = useCallback(() => {
    if (!dialogApp) return;
    setDialogOpen(false);
    setConnectingId(dialogApp.id);

    // Simulate connection delay
    setTimeout(() => {
      setApps((prev) =>
        prev.map((a) =>
          a.id === dialogApp.id ? { ...a, connected: true } : a
        )
      );
      setConnectingId(null);
      setDialogApp(null);
    }, 1500);
  }, [dialogApp]);

  return (
    <>
      <Card className="border-border bg-card md:col-span-2">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
              <Link2 className="h-5 w-5 text-primary" />
              Connect Apps
            </CardTitle>
            <Badge
              variant="outline"
              className="text-xs font-semibold border-primary/30 bg-primary/5 text-primary"
            >
              {connectedCount} / {apps.length} connected
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Link your messaging apps to enable auto-replies, busy mode, and AI tone analysis across all conversations.
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2">
            {visibleApps.map((app) => {
              const isConnecting = connectingId === app.id;

              return (
                <div
                  key={app.id}
                  className={cn(
                    "relative flex items-start gap-3 rounded-xl border p-3.5 transition-all duration-200",
                    app.connected
                      ? "border-primary/20 bg-primary/[0.03]"
                      : "border-border bg-muted/30 hover:bg-muted/50"
                  )}
                >
                  {/* App icon */}
                  <div
                    className="shrink-0 rounded-lg p-2"
                    style={{
                      backgroundColor: app.bgColor,
                      color: app.color,
                    }}
                  >
                    {getAppIcon(app.name)}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-semibold text-foreground">
                        {app.name}
                      </p>
                      {app.connected && (
                        <span className="flex items-center gap-0.5 text-[10px] font-medium text-primary">
                          <Check className="h-3 w-3" />
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mb-2">
                      {app.description}
                    </p>

                    {/* Feature pills */}
                    <div className="flex flex-wrap gap-1 mb-2.5">
                      {app.features.map((feature) => (
                        <span
                          key={feature}
                          className={cn(
                            "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium",
                            app.connected
                              ? "bg-primary/10 text-primary"
                              : "bg-muted text-muted-foreground"
                          )}
                        >
                          {feature}
                        </span>
                      ))}
                    </div>

                    {/* Action button */}
                    <Button
                      size="sm"
                      variant={app.connected ? "outline" : "default"}
                      disabled={isConnecting}
                      onClick={() => handleConnect(app)}
                      className={cn(
                        "h-7 text-xs gap-1.5 transition-colors",
                        app.connected
                          ? "text-muted-foreground hover:text-destructive hover:border-destructive/30"
                          : "bg-primary text-primary-foreground hover:bg-primary/90"
                      )}
                    >
                      {isConnecting ? (
                        <>
                          <Loader2 className="h-3 w-3 animate-spin" />
                          Connecting...
                        </>
                      ) : app.connected ? (
                        <>
                          <Unlink className="h-3 w-3" />
                          Disconnect
                        </>
                      ) : (
                        <>
                          <Link2 className="h-3 w-3" />
                          Connect
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Show more / less */}
          {apps.length > 4 && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1 mx-auto mt-4 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
            >
              {expanded ? (
                <>
                  Show less <ChevronUp className="h-3.5 w-3.5" />
                </>
              ) : (
                <>
                  Show {apps.length - 4} more apps{" "}
                  <ChevronDown className="h-3.5 w-3.5" />
                </>
              )}
            </button>
          )}
        </CardContent>
      </Card>

      {/* Permission dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            {dialogApp && (
              <>
                <div className="flex items-center gap-3 mb-1">
                  <div
                    className="rounded-lg p-2.5"
                    style={{
                      backgroundColor: dialogApp.bgColor,
                      color: dialogApp.color,
                    }}
                  >
                    {getAppIcon(dialogApp.name)}
                  </div>
                  <div>
                    <DialogTitle className="text-foreground text-left">
                      Connect {dialogApp.name}
                    </DialogTitle>
                    <DialogDescription className="text-left mt-0.5">
                      Grant MindLink access to your {dialogApp.name} account
                    </DialogDescription>
                  </div>
                </div>
              </>
            )}
          </DialogHeader>

          {dialogApp && (
            <div className="space-y-4 mt-2">
              <div className="rounded-lg bg-muted/60 p-3.5">
                <p className="text-xs font-semibold text-foreground mb-2.5">
                  MindLink will be able to:
                </p>
                <ul className="space-y-2">
                  {dialogApp.features.map((feature) => (
                    <li
                      key={feature}
                      className="flex items-center gap-2 text-xs text-foreground"
                    >
                      <div className="rounded-full p-0.5 bg-primary/10">
                        <Check
                          className="h-3 w-3 text-primary"
                          strokeWidth={3}
                        />
                      </div>
                      {feature === "Auto-reply" &&
                        "Send automated replies when you're in busy mode"}
                      {feature === "Busy mode" &&
                        "Set your status to busy on this platform"}
                      {feature === "Tone analysis" &&
                        "Analyze incoming & outgoing message tone"}
                      {feature === "Status sync" &&
                        "Sync your stress status with workspace presence"}
                    </li>
                  ))}
                  <li className="flex items-center gap-2 text-xs text-foreground">
                    <div className="rounded-full p-0.5 bg-primary/10">
                      <Shield
                        className="h-3 w-3 text-primary"
                        strokeWidth={3}
                      />
                    </div>
                    Your messages stay private and are never stored
                  </li>
                </ul>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 text-muted-foreground"
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
                  onClick={confirmConnect}
                >
                  <Link2 className="h-3.5 w-3.5" />
                  Authorize
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

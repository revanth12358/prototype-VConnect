"use client";

import { useState, useEffect, useCallback } from "react";
import { Activity, Heart, Wind, Thermometer, Bell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  generateStressData,
  getStressColor,
  getStressBgColor,
} from "@/lib/stress-simulator";

const defaultData = {
  heartRate: 72,
  stressScore: 28,
  stressLevel: "Low" as const,
  hrv: 55,
  respiratoryRate: 16,
  skinTemp: 97.8,
};

export function StressMonitor() {
  const [data, setData] = useState(defaultData);
  const [alertSent, setAlertSent] = useState(false);
  const [history, setHistory] = useState<number[]>([]);
  const [mounted, setMounted] = useState(false);

  const refresh = useCallback(() => {
    const newData = generateStressData();
    setData(newData);
    setHistory((prev) => [...prev.slice(-19), newData.stressScore]);
    if (newData.stressLevel === "High") {
      setAlertSent(true);
      setTimeout(() => setAlertSent(false), 3000);
    }
  }, []);

  useEffect(() => {
    setMounted(true);
    refresh();
    const interval = setInterval(refresh, 3000);
    return () => clearInterval(interval);
  }, [refresh]);

  const circumference = 2 * Math.PI * 54;
  const dashOffset = circumference - (data.stressScore / 100) * circumference;

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
            <Activity className="h-5 w-5 text-primary" />
            Stress Monitoring
          </CardTitle>
          <Badge
            variant="outline"
            className={cn(
              "text-xs font-semibold",
              getStressBgColor(data.stressLevel),
              getStressColor(data.stressLevel),
              "border-transparent"
            )}
          >
            {data.stressLevel}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {/* Circular stress gauge */}
        <div className="flex items-center justify-center mb-6">
          <div className="relative">
            <svg width="140" height="140" viewBox="0 0 140 140" aria-hidden="true">
              <circle
                cx="70"
                cy="70"
                r="54"
                fill="none"
                strokeWidth="10"
                className="stroke-muted"
              />
              <circle
                cx="70"
                cy="70"
                r="54"
                fill="none"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                className={cn(
                  "transition-all duration-700 ease-out",
                  data.stressLevel === "Low" && "stroke-primary",
                  data.stressLevel === "Moderate" && "stroke-accent",
                  data.stressLevel === "High" && "stroke-destructive"
                )}
                transform="rotate(-90 70 70)"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span
                className={cn(
                  "text-3xl font-bold",
                  getStressColor(data.stressLevel)
                )}
              >
                {data.stressScore}
              </span>
              <span className="text-xs text-muted-foreground">Stress Score</span>
            </div>
          </div>
        </div>

        {/* Biometric grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2.5 rounded-lg bg-muted/60 px-3 py-2.5">
            <Heart className="h-4 w-4 text-destructive shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Heart Rate</p>
              <p className="text-sm font-semibold text-card-foreground">
                {data.heartRate} <span className="text-xs font-normal text-muted-foreground">bpm</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-lg bg-muted/60 px-3 py-2.5">
            <Activity className="h-4 w-4 text-primary shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">HRV</p>
              <p className="text-sm font-semibold text-card-foreground">
                {data.hrv} <span className="text-xs font-normal text-muted-foreground">ms</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-lg bg-muted/60 px-3 py-2.5">
            <Wind className="h-4 w-4 text-primary shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Respiratory</p>
              <p className="text-sm font-semibold text-card-foreground">
                {data.respiratoryRate} <span className="text-xs font-normal text-muted-foreground">/min</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-lg bg-muted/60 px-3 py-2.5">
            <Thermometer className="h-4 w-4 text-accent shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Skin Temp</p>
              <p className="text-sm font-semibold text-card-foreground">
                {data.skinTemp}<span className="text-xs font-normal text-muted-foreground">&deg;F</span>
              </p>
            </div>
          </div>
        </div>

        {/* Mini chart */}
        {history.length > 1 && (
          <div className="mt-4 flex items-end gap-[3px] h-10">
            {history.map((score, i) => (
              <div
                key={i}
                className={cn(
                  "flex-1 rounded-t-sm transition-all duration-300",
                  score < 35 && "bg-primary/60",
                  score >= 35 && score < 65 && "bg-accent/60",
                  score >= 65 && "bg-destructive/60"
                )}
                style={{ height: `${Math.max(4, score)}%` }}
              />
            ))}
          </div>
        )}

        {/* Alert banner */}
        {alertSent && (
          <div className="mt-4 flex items-center gap-2 rounded-lg bg-destructive/10 border border-destructive/20 px-3 py-2 animate-in fade-in slide-in-from-top-2 duration-300">
            <Bell className="h-4 w-4 text-destructive shrink-0" />
            <p className="text-xs text-destructive font-medium">
              Alert sent to trusted contacts!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

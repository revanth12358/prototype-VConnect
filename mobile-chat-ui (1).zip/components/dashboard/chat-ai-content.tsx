"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Sparkles, RefreshCw, X, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import Link from "next/link";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  toneAnalysis?: {
    tone: string;
    intentScore: number;
    emotionalTone: string;
    improved: string;
  };
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: "1",
    role: "assistant",
    content:
      "Hi there! I'm your AI Message Clarity Assistant. Type any message you're thinking of sending, and I'll help you analyze its tone and suggest improvements for clearer, kinder communication.",
    timestamp: "Now",
  },
];

export function ChatAIContent() {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showPopup, setShowPopup] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = useCallback(async () => {
    if (!input.trim() || isAnalyzing) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsAnalyzing(true);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg.content }),
      });

      const analysis = await res.json();

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: getAssistantResponse(analysis),
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        }),
        toneAnalysis: {
          tone: analysis.tone || "Neutral",
          intentScore: analysis.intentScore ?? 75,
          emotionalTone: analysis.emotionalTone || "Neutral",
          improved: analysis.improved || userMsg.content,
        },
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content:
          "I had trouble analyzing that message. Try again or check if the AI service is available.",
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsAnalyzing(false);
    }
  }, [input, isAnalyzing]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-8rem)] md:h-[calc(100dvh-5rem)]">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-border mb-4">
        <Button asChild variant="ghost" size="icon" className="h-8 w-8 md:hidden">
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            AI Message Clarity Chat
          </h1>
          <p className="text-xs text-muted-foreground">
            Type any message to analyze its tone and get improvement suggestions
          </p>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-4 pb-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex flex-col max-w-[85%]",
                msg.role === "user" ? "self-end items-end" : "self-start items-start"
              )}
            >
              <div
                className={cn(
                  "rounded-2xl px-4 py-3 text-sm leading-relaxed",
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-card text-card-foreground border border-border rounded-bl-md"
                )}
              >
                {msg.content}
              </div>

              {/* Tone analysis badge for assistant messages */}
              {msg.toneAnalysis && (
                <div className="mt-1.5 flex items-center gap-1.5">
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[10px] cursor-pointer border-transparent",
                      msg.toneAnalysis.tone === "Friendly" && "bg-primary/10 text-primary",
                      msg.toneAnalysis.tone === "Aggressive" && "bg-destructive/10 text-destructive",
                      msg.toneAnalysis.tone === "Confusing" && "bg-accent/10 text-accent",
                      msg.toneAnalysis.tone === "Neutral" && "bg-muted text-muted-foreground"
                    )}
                    onClick={() =>
                      setShowPopup(showPopup === msg.id ? null : msg.id)
                    }
                  >
                    {msg.toneAnalysis.tone} &middot; {msg.toneAnalysis.intentScore}%
                  </Badge>
                </div>
              )}

              {/* Expanded analysis popup */}
              {showPopup === msg.id && msg.toneAnalysis && (
                <div className="mt-2 w-72 rounded-xl border border-border bg-card p-3 shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-200">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-foreground">Detailed Analysis</p>
                    <button
                      onClick={() => setShowPopup(null)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <div className="text-center rounded-md bg-muted/60 py-1.5">
                      <p className="text-[10px] text-muted-foreground">Tone</p>
                      <p className="text-xs font-semibold text-foreground">{msg.toneAnalysis.tone}</p>
                    </div>
                    <div className="text-center rounded-md bg-muted/60 py-1.5">
                      <p className="text-[10px] text-muted-foreground">Clarity</p>
                      <p className="text-xs font-semibold text-foreground">{msg.toneAnalysis.intentScore}%</p>
                    </div>
                    <div className="text-center rounded-md bg-muted/60 py-1.5">
                      <p className="text-[10px] text-muted-foreground">Emotion</p>
                      <p className="text-xs font-semibold text-foreground">{msg.toneAnalysis.emotionalTone}</p>
                    </div>
                  </div>
                  {msg.toneAnalysis.improved !== messages.find(m => m.id === (parseInt(msg.id) - 1).toString())?.content && (
                    <div className="rounded-md bg-primary/5 border border-primary/10 p-2">
                      <p className="text-[10px] font-medium text-primary uppercase tracking-wide mb-1">Suggested</p>
                      <p className="text-xs text-foreground leading-relaxed">{msg.toneAnalysis.improved}</p>
                    </div>
                  )}
                </div>
              )}

              <span className="text-[10px] text-muted-foreground mt-1 px-1">
                {msg.timestamp}
              </span>
            </div>
          ))}
          {isAnalyzing && (
            <div className="self-start flex items-center gap-2 rounded-2xl bg-card border border-border px-4 py-3 rounded-bl-md">
              <RefreshCw className="h-3.5 w-3.5 text-primary animate-spin" />
              <span className="text-sm text-muted-foreground">Analyzing tone...</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      {/* Input area */}
      <div className="border-t border-border pt-3 mt-2">
        <div className="flex items-end gap-2">
          <div className="flex-1 rounded-2xl border border-input bg-card px-4 py-2.5 focus-within:ring-1 focus-within:ring-ring transition-shadow">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message to analyze..."
              rows={1}
              className="w-full text-sm text-foreground placeholder:text-muted-foreground bg-transparent resize-none focus:outline-none leading-relaxed max-h-24"
              aria-label="Message input"
            />
          </div>
          <Button
            size="icon"
            onClick={handleSend}
            disabled={!input.trim() || isAnalyzing}
            className="h-10 w-10 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shrink-0"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-1.5 text-center">
          AI analyzes tone and suggests improvements before you send
        </p>
      </div>
    </div>
  );
}

function getAssistantResponse(analysis: {
  tone?: string;
  intentScore?: number;
  emotionalTone?: string;
  improved?: string;
}): string {
  const tone = analysis.tone || "Neutral";
  const score = analysis.intentScore ?? 75;

  if (tone === "Aggressive") {
    return `I noticed this message has an aggressive tone (clarity: ${score}%). The emotional undertone seems ${analysis.emotionalTone || "frustrated"}. I've suggested a rewritten version that conveys the same message more kindly. Click the badge below to see the full analysis and suggestion.`;
  }
  if (tone === "Confusing") {
    return `This message might be a bit confusing to the recipient (clarity: ${score}%). I've prepared a clearer version that better communicates your intent. Click the badge to see the detailed analysis.`;
  }
  if (tone === "Friendly") {
    return `Great message! It reads as friendly and clear (clarity: ${score}%). Your communication is thoughtful and considerate. Click the badge for the full breakdown.`;
  }
  return `Your message has a neutral tone (clarity: ${score}%). It communicates the point well. Click the badge below for detailed analysis and any suggestions.`;
}

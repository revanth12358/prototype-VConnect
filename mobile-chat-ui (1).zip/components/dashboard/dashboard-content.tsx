"use client";

import { StressMonitor } from "@/components/dashboard/stress-monitor";
import { BusyModePanel } from "@/components/dashboard/busy-mode-panel";
import { AIMessageAssistant } from "@/components/dashboard/ai-message-assistant";
import { NotificationPanel } from "@/components/dashboard/notification-panel";
import { ConnectedAppsPanel } from "@/components/dashboard/connected-apps-panel";

export function DashboardContent() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Monitor your stress, manage communications, and send mindful messages.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <StressMonitor />
        <BusyModePanel />
        <ConnectedAppsPanel />
        <AIMessageAssistant />
        <NotificationPanel />
      </div>
    </div>
  );
}

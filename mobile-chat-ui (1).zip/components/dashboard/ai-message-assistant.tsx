"use client";

import { useState } from "react";
import { Sparkles, ArrowRight, RefreshCw, Copy, Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface AnalysisResult {
  tone: string;
  intentScore: number;
  emotionalTone: string;
  original: string;
  improved: string;
  isLoading?: boolean;
}

export function AIMessageAssistant() {
  const [message, setMessage] = useState("");
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleAnalyze = async () => {
    if (!message.trim()) return;
    setIsLoading(true);
    setAnalysis(null);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: message.trim() }),
      });

      if (!res.ok) throw new Error("Analysis failed");

      const data = await res.json();
      setAnalysis({
        tone: data.tone || "Neutral",
        intentScore: data.intentScore ?? 75,
        emotionalTone: data.emotionalTone || "Neutral",
        original: message.trim(),
        improved: data.improved || message.trim(),
      });
    } catch {
      // Fallback to client-side analysis if AI API unavailable
      setAnalysis(getFallbackAnalysis(message.trim()));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (analysis?.improved) {
      navigator.clipboard.writeText(analysis.improved);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleUseImproved = () => {
    if (analysis?.improved) {
      setMessage(analysis.improved);
      setAnalysis(null);
    }
  };

  const toneColor =
    analysis?.tone === "Friendly"
      ? "text-primary"
      : analysis?.tone === "Aggressive"
        ? "text-destructive"
        : analysis?.tone === "Confusing"
          ? "text-accent"
          : "text-muted-foreground";

  const toneBg =
    analysis?.tone === "Friendly"
      ? "bg-primary/10"
      : analysis?.tone === "Aggressive"
        ? "bg-destructive/10"
        : analysis?.tone === "Confusing"
          ? "bg-accent/10"
          : "bg-muted";

  return (
    <Card className="border-border bg-card md:col-span-2">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
          <Sparkles className="h-5 w-5 text-primary" />
          AI Message Clarity Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Input area */}
        <div className="mb-4">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type a message you want to analyze before sending..."
            rows={3}
            className="w-full text-sm text-foreground bg-muted/60 rounded-lg border border-input p-3 resize-none focus:outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground leading-relaxed"
          />
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-muted-foreground">
              AI will analyze tone, intent, and suggest improvements
            </p>
            <Button
              size="sm"
              onClick={handleAnalyze}
              disabled={!message.trim() || isLoading}
              className="gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {isLoading ? (
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Sparkles className="h-3.5 w-3.5" />
              )}
              Analyze
            </Button>
          </div>
        </div>

        {/* Analysis result */}
        {analysis && (
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            {/* Metrics row */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="rounded-lg bg-muted/60 p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Tone</p>
                <Badge variant="outline" className={cn("text-xs font-semibold border-transparent", toneBg, toneColor)}>
                  {analysis.tone}
                </Badge>
              </div>
              <div className="rounded-lg bg-muted/60 p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Intent Score</p>
                <p className="text-lg font-bold text-card-foreground">{analysis.intentScore}%</p>
              </div>
              <div className="rounded-lg bg-muted/60 p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Emotional Tone</p>
                <p className="text-sm font-semibold text-card-foreground">{analysis.emotionalTone}</p>
              </div>
            </div>

            {/* Side-by-side comparison */}
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3">
                <p className="text-xs font-medium text-destructive uppercase tracking-wide mb-2">
                  Original
                </p>
                <p className="text-sm text-foreground leading-relaxed">
                  {analysis.original}
                </p>
              </div>
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-medium text-primary uppercase tracking-wide">
                    Improved
                  </p>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleCopy}
                      className="text-primary hover:text-primary/80 transition-colors"
                      aria-label="Copy improved message"
                    >
                      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
                <p className="text-sm text-foreground leading-relaxed">
                  {analysis.improved}
                </p>
              </div>
            </div>

            <Button
              size="sm"
              variant="outline"
              onClick={handleUseImproved}
              className="mt-3 w-full gap-1.5"
            >
              <ArrowRight className="h-3.5 w-3.5" />
              Use Improved Version
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Fallback analysis when AI API is unavailable
function getFallbackAnalysis(text: string): AnalysisResult {
  const lower = text.toLowerCase();
  const hasAggression =
    /why can't you|you never|you always|what's wrong|are you kidding|ridiculous/i.test(lower);
  const hasConfusion = /\?\?|what do you mean|i don't understand|huh/i.test(lower);
  const allCaps = text === text.toUpperCase() && text.length > 5 && /[A-Z]/.test(text);

  let tone: string;
  let intentScore: number;
  let emotionalTone: string;
  let improved: string;

  if (hasAggression || allCaps) {
    tone = "Aggressive";
    intentScore = Math.round(30 + Math.random() * 20);
    emotionalTone = "Frustrated";
    improved = text
      .replace(/why can't you/gi, "I'd appreciate it if you could")
      .replace(/you never/gi, "I've noticed that sometimes")
      .replace(/you always/gi, "It sometimes feels like")
      .replace(/!/g, ".");
    if (allCaps) improved = improved.charAt(0) + improved.slice(1).toLowerCase();
  } else if (hasConfusion) {
    tone = "Confusing";
    intentScore = Math.round(50 + Math.random() * 15);
    emotionalTone = "Uncertain";
    improved = `I'd like to better understand what you meant. Could you clarify? Here's what I think: ${text}`;
  } else {
    tone = "Friendly";
    intentScore = Math.round(80 + Math.random() * 15);
    emotionalTone = "Calm";
    improved = text;
  }

  return { tone, intentScore, emotionalTone, original: text, improved };
}

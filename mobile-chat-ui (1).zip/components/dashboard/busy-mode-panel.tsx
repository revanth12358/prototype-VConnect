"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Moon,
  Pencil,
  UserMinus,
  Clock,
  X,
  MessageCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MOCK_CONTACTS, MOCK_MESSAGE_LOGS, type Contact } from "@/lib/mock-data";

const RESTRICTION_DURATION = 4 * 60 * 60; // 4 hours in seconds

export function BusyModePanel() {
  const [busyMode, setBusyMode] = useState(false);
  const [autoReply, setAutoReply] = useState(
    "I'm taking some time for myself right now. I'll get back to you when I'm ready."
  );
  const [isEditing, setIsEditing] = useState(false);
  const [contacts, setContacts] = useState<Contact[]>(MOCK_CONTACTS);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [timerLeft, setTimerLeft] = useState(0);

  const restrictedContacts = contacts.filter((c) => c.isRestricted);

  const handleRestrict = useCallback((contactId: string) => {
    setContacts((prev) =>
      prev.map((c) =>
        c.id === contactId
          ? { ...c, isRestricted: true, restrictedUntil: Date.now() + RESTRICTION_DURATION * 1000 }
          : c
      )
    );
    setTimerLeft(RESTRICTION_DURATION);
    setDialogOpen(false);
  }, []);

  const handleUnrestrict = useCallback((contactId: string) => {
    setContacts((prev) =>
      prev.map((c) =>
        c.id === contactId ? { ...c, isRestricted: false, restrictedUntil: undefined } : c
      )
    );
  }, []);

  // Countdown timer
  useEffect(() => {
    if (restrictedContacts.length === 0) return;
    const interval = setInterval(() => {
      setTimerLeft((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [restrictedContacts.length]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h}h ${m.toString().padStart(2, "0")}m ${s.toString().padStart(2, "0")}s`;
  };

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
            <Moon className="h-5 w-5 text-accent" />
            Busy Mode
          </CardTitle>
          <Switch
            id="busy-mode-dashboard"
            checked={busyMode}
            onCheckedChange={setBusyMode}
            aria-label="Toggle busy mode"
          />
        </div>
      </CardHeader>
      <CardContent>
        {/* Auto-reply template */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Auto-reply template
            </Label>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="text-primary hover:text-primary/80 transition-colors"
              aria-label="Edit auto-reply"
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
          </div>
          {isEditing ? (
            <textarea
              value={autoReply}
              onChange={(e) => setAutoReply(e.target.value)}
              onBlur={() => setIsEditing(false)}
              autoFocus
              rows={2}
              className="w-full text-sm text-foreground bg-muted/60 rounded-lg border border-input p-3 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />
          ) : (
            <div className="rounded-lg bg-muted/60 p-3">
              <p className="text-sm text-foreground/80 italic leading-relaxed">
                {`"${autoReply}"`}
              </p>
            </div>
          )}
        </div>

        {/* Restrict contacts */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Restricted Contacts
            </Label>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 text-xs text-primary hover:text-primary/80 hover:bg-primary/10 gap-1">
                  <UserMinus className="h-3.5 w-3.5" />
                  Add
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-sm">
                <DialogHeader>
                  <DialogTitle className="text-foreground">Restrict Contact (4 hours)</DialogTitle>
                </DialogHeader>
                <div className="flex flex-col gap-2 mt-2 max-h-60 overflow-y-auto">
                  {contacts
                    .filter((c) => !c.isRestricted)
                    .map((contact) => (
                      <button
                        key={contact.id}
                        onClick={() => handleRestrict(contact.id)}
                        className="flex items-center gap-3 rounded-lg p-2.5 hover:bg-muted transition-colors text-left"
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-secondary text-secondary-foreground text-xs font-semibold">
                            {contact.initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{contact.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{contact.platform}</p>
                        </div>
                      </button>
                    ))}
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {restrictedContacts.length > 0 ? (
            <div className="flex flex-col gap-2">
              {restrictedContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center justify-between rounded-lg bg-destructive/5 border border-destructive/10 px-3 py-2"
                >
                  <div className="flex items-center gap-2">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-destructive/10 text-destructive text-xs font-semibold">
                        {contact.initials}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-xs font-medium text-foreground">{contact.name}</p>
                      {timerLeft > 0 && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Clock className="h-2.5 w-2.5" />
                          {formatTime(timerLeft)}
                        </p>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => handleUnrestrict(contact.id)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    aria-label={`Remove restriction for ${contact.name}`}
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-3">
              No contacts restricted
            </p>
          )}
        </div>

        {/* Message activity log */}
        <div>
          <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2 block">
            Recent Messages
          </Label>
          <ScrollArea className="h-36">
            <div className="flex flex-col gap-1.5">
              {MOCK_MESSAGE_LOGS.map((msg) => (
                <div
                  key={msg.id}
                  className="flex items-start gap-2 rounded-lg px-2.5 py-2 bg-muted/40"
                >
                  <MessageCircle className="h-3.5 w-3.5 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-medium text-foreground">{msg.contactName}</p>
                      {msg.isAutoReply && (
                        <Badge variant="outline" className="text-[10px] h-4 px-1.5 text-primary border-primary/30 bg-primary/5">
                          Auto
                        </Badge>
                      )}
                      <span className="text-[10px] text-muted-foreground ml-auto">{msg.timestamp}</span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
}

"use client";

import { Bell, MessageCircle, Phone, Heart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MOCK_CONTACTS } from "@/lib/mock-data";

const notifications = [
  {
    id: "n1",
    type: "alert" as const,
    contact: MOCK_CONTACTS[0],
    message: "Stress alert: High stress level detected",
    time: "Just now",
  },
  {
    id: "n2",
    type: "calm" as const,
    contact: MOCK_CONTACTS[1],
    message: "Sent you a calm message",
    time: "5 min ago",
  },
  {
    id: "n3",
    type: "call" as const,
    contact: MOCK_CONTACTS[3],
    message: "Requested a quick check-in call",
    time: "15 min ago",
  },
];

export function NotificationPanel() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
          <Bell className="h-5 w-5 text-accent" />
          Trusted Contact Alerts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className="flex items-start gap-3 rounded-lg bg-muted/40 p-3"
            >
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                  {notif.contact.initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-xs font-semibold text-foreground">{notif.contact.name}</p>
                  <span className="text-[10px] text-muted-foreground ml-auto">{notif.time}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{notif.message}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 text-[10px] text-primary hover:text-primary/80 hover:bg-primary/10 gap-1 px-2"
                  >
                    <Heart className="h-3 w-3" />
                    Send Calm
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 text-[10px] text-primary hover:text-primary/80 hover:bg-primary/10 gap-1 px-2"
                  >
                    <Phone className="h-3 w-3" />
                    Quick Call
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

"use client";

import { useState } from "react";
import {
  Settings,
  Watch,
  MessageCircle,
  Smartphone,
  Sliders,
  FileText,
  Wifi,
  WifiOff,
  Plus,
  Trash2,
  Check,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { MOCK_DEVICES, MOCK_PLATFORMS } from "@/lib/mock-data";

export function SettingsContent() {
  const [devices, setDevices] = useState(MOCK_DEVICES);
  const [platforms, setPlatforms] = useState(MOCK_PLATFORMS);
  const [threshold, setThreshold] = useState([70]);
  const [notifications, setNotifications] = useState(true);
  const [autoAlert, setAutoAlert] = useState(true);
  const [templates, setTemplates] = useState([
    "I'm taking some time for myself right now. I'll get back to you when I'm ready.",
    "I'm in focus mode at the moment. Will reply when available.",
    "Currently unavailable. Your message is important to me and I'll respond soon.",
  ]);
  const [newTemplate, setNewTemplate] = useState("");
  const [saved, setSaved] = useState(false);

  const toggleDevice = (id: string) => {
    setDevices((prev) =>
      prev.map((d) =>
        d.id === id ? { ...d, connected: !d.connected } : d
      )
    );
  };

  const togglePlatform = (id: string) => {
    setPlatforms((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, connected: !p.connected } : p
      )
    );
  };

  const addTemplate = () => {
    if (!newTemplate.trim()) return;
    setTemplates((prev) => [...prev, newTemplate.trim()]);
    setNewTemplate("");
  };

  const removeTemplate = (index: number) => {
    setTemplates((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Configure devices, thresholds, and auto-reply templates.
          </p>
        </div>
        <Button
          size="sm"
          onClick={handleSave}
          className={cn(
            "gap-1.5 transition-colors",
            saved
              ? "bg-primary text-primary-foreground"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          )}
        >
          {saved ? <Check className="h-4 w-4" /> : <Settings className="h-4 w-4" />}
          {saved ? "Saved" : "Save"}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Connected Devices */}
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
              <Watch className="h-5 w-5 text-primary" />
              Connected Devices
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {devices.map((device) => (
                <div
                  key={device.id}
                  className="flex items-center justify-between rounded-lg bg-muted/40 p-3"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        "rounded-full p-2",
                        device.connected
                          ? "bg-primary/10 text-primary"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {device.connected ? (
                        <Wifi className="h-4 w-4" />
                      ) : (
                        <WifiOff className="h-4 w-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{device.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {device.type.replace("_", " ")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px] border-transparent",
                        device.connected
                          ? "bg-primary/10 text-primary"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {device.connected ? "Connected" : "Disconnected"}
                    </Badge>
                    <Switch
                      checked={device.connected}
                      onCheckedChange={() => toggleDevice(device.id)}
                      aria-label={`Toggle ${device.name}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Connected Platforms */}
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
              <MessageCircle className="h-5 w-5 text-accent" />
              Messaging Platforms
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {platforms.map((platform) => (
                <div
                  key={platform.id}
                  className="flex items-center justify-between rounded-lg bg-muted/40 p-3"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        "rounded-full p-2",
                        platform.connected
                          ? "bg-accent/10 text-accent"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {platform.name === "SMS" ? (
                        <Smartphone className="h-4 w-4" />
                      ) : (
                        <MessageCircle className="h-4 w-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{platform.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {platform.connected ? "Active integration" : "Not connected"}
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={platform.connected}
                    onCheckedChange={() => togglePlatform(platform.id)}
                    aria-label={`Toggle ${platform.name}`}
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stress Threshold */}
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
              <Sliders className="h-5 w-5 text-destructive" />
              Stress Threshold
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <Label className="text-sm text-foreground">Alert Threshold</Label>
                  <span
                    className={cn(
                      "text-lg font-bold",
                      threshold[0] >= 80 ? "text-destructive" : threshold[0] >= 50 ? "text-accent" : "text-primary"
                    )}
                  >
                    {threshold[0]}
                  </span>
                </div>
                <Slider
                  value={threshold}
                  onValueChange={setThreshold}
                  max={100}
                  min={20}
                  step={5}
                  className="py-2"
                />
                <div className="flex justify-between mt-2">
                  <span className="text-[10px] text-primary font-medium">Low (20)</span>
                  <span className="text-[10px] text-accent font-medium">Moderate (50)</span>
                  <span className="text-[10px] text-destructive font-medium">High (100)</span>
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm text-foreground">Push Notifications</Label>
                  <p className="text-xs text-muted-foreground">
                    Alert you when stress is high
                  </p>
                </div>
                <Switch
                  checked={notifications}
                  onCheckedChange={setNotifications}
                  aria-label="Toggle notifications"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm text-foreground">Auto-Alert Contacts</Label>
                  <p className="text-xs text-muted-foreground">
                    Notify trusted contacts automatically
                  </p>
                </div>
                <Switch
                  checked={autoAlert}
                  onCheckedChange={setAutoAlert}
                  aria-label="Toggle auto-alert"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Auto-Reply Templates */}
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-card-foreground">
              <FileText className="h-5 w-5 text-primary" />
              Auto-Reply Templates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2 mb-4">
              {templates.map((template, index) => (
                <div
                  key={index}
                  className="flex items-start gap-2 rounded-lg bg-muted/40 p-3 group"
                >
                  <p className="flex-1 text-sm text-foreground leading-relaxed">
                    {template}
                  </p>
                  <button
                    onClick={() => removeTemplate(index)}
                    className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100 shrink-0 mt-0.5"
                    aria-label="Remove template"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add new template..."
                value={newTemplate}
                onChange={(e) => setNewTemplate(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addTemplate()}
                className="text-sm"
              />
              <Button
                size="sm"
                variant="outline"
                onClick={addTemplate}
                disabled={!newTemplate.trim()}
                className="shrink-0 gap-1"
              >
                <Plus className="h-3.5 w-3.5" />
                Add
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

"use client";

import { ChevronLeft, Phone, Video } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

interface ChatHeaderProps {
  name: string;
  status: string;
}

export function ChatHeader({ name, status }: ChatHeaderProps) {
  return (
    <header className="flex items-center gap-3 border-b border-border bg-card px-4 py-3">
      <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground" aria-label="Go back">
        <ChevronLeft className="h-5 w-5" />
      </Button>
      <Avatar className="h-9 w-9">
        <AvatarFallback className="bg-primary text-primary-foreground text-sm font-semibold">
          {name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <h1 className="text-sm font-semibold text-foreground leading-tight truncate">
          {name}
        </h1>
        <p className="text-xs text-muted-foreground leading-tight">{status}</p>
      </div>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" aria-label="Audio call">
          <Phone className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" aria-label="Video call">
          <Video className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}

"use client";

import { cn } from "@/lib/utils";

export interface Message {
  id: string;
  text: string;
  sender: "me" | "other";
  timestamp: string;
  isAutoReply?: boolean;
}

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isMe = message.sender === "me";

  return (
    <div
      className={cn("flex flex-col max-w-[80%]", isMe ? "self-end items-end" : "self-start items-start")}
    >
      <div
        className={cn(
          "rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
          isMe
            ? "bg-primary text-primary-foreground rounded-br-md"
            : "bg-card text-card-foreground border border-border rounded-bl-md"
        )}
      >
        {message.isAutoReply && (
          <span className="block text-[10px] font-semibold uppercase tracking-wider opacity-70 mb-1">
            Auto-reply
          </span>
        )}
        {message.text}
      </div>
      <span className="text-[10px] text-muted-foreground mt-1 px-1">
        {message.timestamp}
      </span>
    </div>
  );
}

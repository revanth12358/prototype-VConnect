"use client";

import { useState, useRef, useEffect } from "react";
import { ChatHeader } from "@/components/chat-header";
import { BusyModeBanner } from "@/components/busy-mode-banner";
import { MessageBubble, type Message } from "@/components/message-bubble";
import { ChatInput } from "@/components/chat-input";
import { ScrollArea } from "@/components/ui/scroll-area";

const INITIAL_MESSAGES: Message[] = [
  {
    id: "1",
    text: "Hey! How are you feeling today?",
    sender: "other",
    timestamp: "10:32 AM",
  },
  {
    id: "2",
    text: "I'm doing well, thanks for asking! Just finished my morning meditation.",
    sender: "me",
    timestamp: "10:33 AM",
  },
  {
    id: "3",
    text: "That's wonderful! How long have you been keeping up the practice?",
    sender: "other",
    timestamp: "10:34 AM",
  },
  {
    id: "4",
    text: "About three weeks now. It really helps me stay grounded throughout the day.",
    sender: "me",
    timestamp: "10:35 AM",
  },
  {
    id: "5",
    text: "I've been meaning to start too. Any tips for a beginner?",
    sender: "other",
    timestamp: "10:36 AM",
  },
];

const AUTO_REPLY_TEXT =
  "Hey! I'm taking some time for myself right now. I'll get back to you when I'm ready.";

export function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [busyMode, setBusyMode] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (text: string) => {
    const now = new Date();
    const timeString = now.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });

    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: "me",
      timestamp: timeString,
    };

    setMessages((prev) => [...prev, newMessage]);

    if (busyMode) {
      setTimeout(() => {
        const autoReply: Message = {
          id: (Date.now() + 1).toString(),
          text: AUTO_REPLY_TEXT,
          sender: "me",
          timestamp: new Date().toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
          }),
          isAutoReply: true,
        };
        setMessages((prev) => [...prev, autoReply]);
      }, 800);
    }
  };

  return (
    <div className="flex flex-col h-dvh max-w-md mx-auto bg-background shadow-2xl">
      <ChatHeader
        name="Alex Chen"
        status={busyMode ? "Busy mode active" : "Online"}
      />

      <BusyModeBanner enabled={busyMode} onToggle={setBusyMode} />

      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-3 p-4">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      <ChatInput onSend={handleSend} />
    </div>
  );
}

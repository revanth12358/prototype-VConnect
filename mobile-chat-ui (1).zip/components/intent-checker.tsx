"use client";

import { useState } from "react";
import { Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface IntentCheckerProps {
  message: string;
}

interface ToneAnalysis {
  tone: string;
  suggestion: string;
  severity: "gentle" | "moderate" | "strong";
}

function analyzeTone(text: string): ToneAnalysis | null {
  if (!text.trim()) return null;

  const lower = text.toLowerCase();

  const aggressivePatterns = [
    "why can't you",
    "you never",
    "you always",
    "what's wrong with you",
    "are you kidding",
    "seriously?",
    "i can't believe",
    "that's ridiculous",
    "how dare",
    "what the",
  ];

  const passiveAggressivePatterns = [
    "fine",
    "whatever",
    "sure, go ahead",
    "i guess",
    "if you say so",
    "no worries",
    "it's fine",
    "not that it matters",
    "i don't care",
  ];

  const anxiousPatterns = [
    "are you mad",
    "did i do something",
    "i'm sorry",
    "please don't",
    "i didn't mean",
    "are you okay",
    "is everything okay",
    "sorry if",
  ];

  const allCaps = text === text.toUpperCase() && text.length > 5 && /[A-Z]/.test(text);
  const excessiveExclamation = (text.match(/!/g) || []).length >= 3;
  const excessiveQuestionMarks = (text.match(/\?/g) || []).length >= 3;

  if (
    allCaps ||
    excessiveExclamation ||
    aggressivePatterns.some((p) => lower.includes(p))
  ) {
    return {
      tone: "Aggressive",
      suggestion:
        "This sounds a bit aggressive. Did you mean to be firm instead? Try rephrasing to express your feelings without blame.",
      severity: "strong",
    };
  }

  if (passiveAggressivePatterns.some((p) => lower.includes(p))) {
    return {
      tone: "Passive-aggressive",
      suggestion:
        "This might come across as dismissive. If something is bothering you, it may help to express it directly and kindly.",
      severity: "moderate",
    };
  }

  if (
    excessiveQuestionMarks ||
    anxiousPatterns.some((p) => lower.includes(p))
  ) {
    return {
      tone: "Anxious",
      suggestion:
        "It sounds like you might be feeling worried. Take a breath. Your feelings are valid, and it's okay to ask for clarity.",
      severity: "gentle",
    };
  }

  return {
    tone: "Thoughtful",
    suggestion:
      "Your message sounds clear and considerate. You're communicating mindfully!",
    severity: "gentle",
  };
}

export function IntentChecker({ message }: IntentCheckerProps) {
  const [analysis, setAnalysis] = useState<ToneAnalysis | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleCheck = () => {
    const result = analyzeTone(message);
    setAnalysis(result);
    setIsAnimating(true);
    setIsVisible(true);
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(() => setAnalysis(null), 200);
  };

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="sm"
        onClick={handleCheck}
        disabled={!message.trim()}
        className="text-xs text-primary hover:text-primary/80 hover:bg-primary/10 h-7 gap-1.5 px-2"
      >
        <Sparkles className="h-3.5 w-3.5" />
        Check Intent
      </Button>

      {analysis && isVisible && (
        <div
          className={cn(
            "absolute bottom-full left-0 right-0 mb-2 rounded-xl border bg-card shadow-lg p-4 z-50 transition-all duration-200",
            isAnimating
              ? "animate-in fade-in slide-in-from-bottom-2"
              : "",
            !isVisible && "animate-out fade-out slide-out-to-bottom-2"
          )}
          role="alert"
          aria-live="polite"
        >
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <div
                className={cn(
                  "h-2 w-2 rounded-full",
                  analysis.severity === "gentle" && "bg-primary",
                  analysis.severity === "moderate" && "bg-accent",
                  analysis.severity === "strong" && "bg-destructive"
                )}
              />
              <span className="text-xs font-semibold text-foreground uppercase tracking-wide">
                {analysis.tone}
              </span>
            </div>
            <button
              onClick={handleDismiss}
              className="text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Dismiss tone analysis"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {analysis.suggestion}
          </p>
        </div>
      )}
    </div>
  );
}

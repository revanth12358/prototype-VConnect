"use client";

import { useState } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { IntentChecker } from "@/components/intent-checker";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSend = () => {
    if (!message.trim()) return;
    onSend(message.trim());
    setMessage("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-border bg-card px-4 pt-2 pb-4">
      <div className="flex items-end gap-2">
        <div className="flex-1 rounded-2xl border border-input bg-background px-4 py-2.5 focus-within:ring-1 focus-within:ring-ring transition-shadow">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={disabled ? "Busy mode is on..." : "Type a message..."}
            disabled={disabled}
            rows={1}
            className="w-full text-sm text-foreground placeholder:text-muted-foreground bg-transparent resize-none focus:outline-none leading-relaxed max-h-24 disabled:opacity-50"
            aria-label="Message input"
          />
        </div>
        <Button
          size="icon"
          onClick={handleSend}
          disabled={!message.trim() || disabled}
          className="h-10 w-10 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shrink-0"
          aria-label="Send message"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
      <div className="mt-1.5 flex items-center">
        <IntentChecker message={message} />
      </div>
    </div>
  );
}

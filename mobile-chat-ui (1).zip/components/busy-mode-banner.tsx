"use client";

import { Moon, Pencil } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useState } from "react";

interface BusyModeBannerProps {
  enabled: boolean;
  onToggle: (value: boolean) => void;
}

const DEFAULT_REPLY =
  "Hey! I'm taking some time for myself right now. I'll get back to you when I'm ready.";

export function BusyModeBanner({ enabled, onToggle }: BusyModeBannerProps) {
  const [autoReply, setAutoReply] = useState(DEFAULT_REPLY);
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="border-b border-border bg-secondary/60 px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Moon className="h-4 w-4 text-primary" />
          <Label
            htmlFor="busy-mode"
            className="text-sm font-medium text-foreground cursor-pointer"
          >
            Busy Mode
          </Label>
        </div>
        <Switch
          id="busy-mode"
          checked={enabled}
          onCheckedChange={onToggle}
          aria-label="Toggle busy mode"
        />
      </div>

      {enabled && (
        <div className="mt-3 rounded-lg bg-card border border-border p-3 animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Auto-reply preview
            </p>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="text-primary hover:text-primary/80 transition-colors"
              aria-label="Edit auto-reply"
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
          </div>
          {isEditing ? (
            <textarea
              value={autoReply}
              onChange={(e) => setAutoReply(e.target.value)}
              onBlur={() => setIsEditing(false)}
              autoFocus
              rows={2}
              className="w-full text-sm text-foreground bg-secondary/50 rounded-md border border-input p-2 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />
          ) : (
            <p className="text-sm text-foreground/80 italic leading-relaxed">
              {`"${autoReply}"`}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

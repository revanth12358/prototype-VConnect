import { Activity, Moon, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const FEATURES = [
  {
    icon: Activity,
    title: "Smart Stress Monitoring",
    description:
      "Connect wearable devices to track real-time stress levels, heart rate, and behavioral indicators. Alerts trusted contacts automatically when thresholds are crossed.",
    color: "text-primary bg-primary/10",
  },
  {
    icon: Moon,
    title: "Smart Auto-Reply & Restriction",
    description:
      "Toggle Busy Mode to send automatic replies. Temporarily restrict specific contacts for up to 4 hours. Full message activity logging with auto-response tags.",
    color: "text-accent bg-accent/10",
  },
  {
    icon: Sparkles,
    title: "AI Message Clarity Assistant",
    description:
      "Before hitting send, AI analyzes tone and intent. Get real-time sentiment scoring and rewritten suggestions for clearer, kinder communication.",
    color: "text-destructive bg-destructive/10",
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="bg-muted/50 py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="text-center mb-16">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary mb-3">
            Core Features
          </p>
          <h2 className="text-3xl font-bold text-foreground text-balance md:text-4xl">
            Everything you need to communicate mindfully
          </h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {FEATURES.map((feature) => (
            <Card
              key={feature.title}
              className="border-border bg-card hover:shadow-lg transition-shadow duration-300"
            >
              <CardContent className="pt-8 pb-8 px-6">
                <div
                  className={`inline-flex items-center justify-center rounded-xl p-3 mb-5 ${feature.color}`}
                >
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-card-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

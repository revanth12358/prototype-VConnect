import Link from "next/link";
import { ArrowRight, Shield, Brain, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-background">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(168_55%_40%/0.08),transparent_60%)]" />
      <div className="relative mx-auto max-w-6xl px-6 pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="flex flex-col items-center text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-medium text-primary">
            <Shield className="h-4 w-4" />
            Protect your mental well-being
          </div>
          <h1 className="max-w-4xl text-4xl font-bold tracking-tight text-foreground text-balance md:text-6xl lg:text-7xl">
            Prevent emotional breakdowns before they happen
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground leading-relaxed md:text-xl">
            MindLink combines real-time stress monitoring with intelligent
            communication automation and AI-powered message clarity to keep you
            grounded.
          </p>
          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Link href="/dashboard">
                Go to Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="h-12 px-8 text-base font-semibold"
            >
              <Link href="#features">Learn More</Link>
            </Button>
          </div>
        </div>

        {/* Stats row */}
        <div className="mt-20 grid grid-cols-3 gap-6 border-t border-border pt-10 md:gap-12">
          <div className="text-center">
            <p className="text-3xl font-bold text-foreground md:text-4xl">93%</p>
            <p className="mt-1 text-sm text-muted-foreground">Stress detection accuracy</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-foreground md:text-4xl">2.4s</p>
            <p className="mt-1 text-sm text-muted-foreground">Average alert time</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-foreground md:text-4xl">78%</p>
            <p className="mt-1 text-sm text-muted-foreground">Fewer misunderstandings</p>
          </div>
        </div>
      </div>
    </section>
  );
}

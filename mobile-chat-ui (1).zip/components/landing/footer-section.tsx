import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function FooterSection() {
  return (
    <footer className="bg-background border-t border-border">
      {/* CTA section */}
      <div className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="text-3xl font-bold text-foreground text-balance md:text-4xl">
          Ready to take control of your well-being?
        </h2>
        <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
          Start monitoring your stress, automating your boundaries, and
          communicating with clarity today.
        </p>
        <Button
          asChild
          size="lg"
          className="mt-8 h-12 px-8 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Link href="/dashboard">
            Launch MindLink
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-border py-6">
        <div className="mx-auto max-w-6xl px-6 flex flex-col items-center gap-3 md:flex-row md:justify-between">
          <p className="text-sm font-semibold text-foreground tracking-tight">
            Mind<span className="text-primary">Link</span>
          </p>
          <p className="text-xs text-muted-foreground">
            Built for hackathon demonstration purposes. No real data is collected.
          </p>
        </div>
      </div>
    </footer>
  );
}

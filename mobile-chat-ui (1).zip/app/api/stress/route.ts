// Mock stress data API simulating wearable device data
export async function GET() {
  const baseHR = 72;
  const variance = Math.random() * 40 - 10;
  const heartRate = Math.round(baseHR + variance);

  let stressLevel: "Low" | "Moderate" | "High";
  let stressScore: number;

  if (heartRate < 80) {
    stressScore = Math.round(20 + Math.random() * 15);
    stressLevel = "Low";
  } else if (heartRate < 95) {
    stressScore = Math.round(40 + Math.random() * 25);
    stressLevel = "Moderate";
  } else {
    stressScore = Math.round(70 + Math.random() * 25);
    stressLevel = "High";
  }

  stressScore = Math.min(100, Math.max(0, stressScore));

  return Response.json({
    heartRate,
    stressScore,
    stressLevel,
    hrv: Math.round(40 + Math.random() * 30),
    respiratoryRate: Math.round(14 + Math.random() * 6),
    skinTemp: +(97 + Math.random() * 2).toFixed(1),
    timestamp: new Date().toISOString(),
  });
}

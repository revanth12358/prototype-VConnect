// Mock auto-reply API simulating WhatsApp/Instagram/SMS auto-responses
export async function POST(req: Request) {
  const body = await req.json();
  const { platform, contactName, template } = body;

  // Simulate sending an auto-reply
  await new Promise((resolve) => setTimeout(resolve, 300));

  return Response.json({
    success: true,
    message: {
      id: Date.now().toString(),
      platform: platform || "sms",
      contactName: contactName || "Unknown",
      text: template || "I'm currently unavailable. Will get back to you soon.",
      timestamp: new Date().toISOString(),
      isAutoReply: true,
    },
  });
}

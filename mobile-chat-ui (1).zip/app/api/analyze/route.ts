import { generateText, Output } from "ai";
import { z } from "zod";

const analysisSchema = z.object({
  tone: z.enum(["Friendly", "Aggressive", "Neutral", "Confusing"]),
  intentScore: z.number().min(0).max(100),
  emotionalTone: z.string(),
  improved: z.string(),
});

export async function POST(req: Request) {
  let message = "";

  try {
    const body = await req.json();
    message = body.message || "";

    if (!message || typeof message !== "string") {
      return Response.json({ error: "Message is required" }, { status: 400 });
    }

    const { output } = await generateText({
      model: "openai/gpt-4o-mini",
      output: Output.object({ schema: analysisSchema }),
      messages: [
        {
          role: "system",
          content: `You are a communication clarity assistant for a mental well-being app called MindLink. 
Analyze the user's message and provide:
1. tone: The overall tone (Friendly, Aggressive, Neutral, or Confusing)
2. intentScore: A 0-100 score of how clear the intent is (100 = perfectly clear)
3. emotionalTone: A one-word emotional descriptor (e.g., Calm, Frustrated, Anxious, Happy, Worried, Confused)
4. improved: A rewritten version of the message that is clearer, kinder, and more mindful while preserving the original intent. If the message is already well-written, return it mostly unchanged.`,
        },
        {
          role: "user",
          content: `Analyze this message: "${message}"`,
        },
      ],
    });

    return Response.json(output);
  } catch {
    // Fallback analysis when AI is unavailable
    return Response.json(getFallbackAnalysis(message));
  }
}

function getFallbackAnalysis(text: string) {
  const lower = (text || "").toLowerCase();
  const hasAggression = /why can't you|you never|you always|ridiculous/i.test(lower);
  const allCaps = text === text.toUpperCase() && text.length > 5;

  if (hasAggression || allCaps) {
    return {
      tone: "Aggressive",
      intentScore: 35,
      emotionalTone: "Frustrated",
      improved: `I'd like to share how I'm feeling about this situation. ${text.charAt(0).toUpperCase() + text.slice(1).toLowerCase().replace(/!/g, ".")}`,
    };
  }

  return {
    tone: "Neutral",
    intentScore: 75,
    emotionalTone: "Calm",
    improved: text,
  };
}

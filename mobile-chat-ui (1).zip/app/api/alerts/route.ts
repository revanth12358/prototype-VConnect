// Mock alert API simulating trusted contact notifications
export async function POST(req: Request) {
  const body = await req.json();
  const { contactIds, stressLevel, type } = body;

  // Simulate sending alerts
  await new Promise((resolve) => setTimeout(resolve, 200));

  return Response.json({
    success: true,
    alertsSent: (contactIds || []).length,
    type: type || "stress_alert",
    stressLevel: stressLevel || "High",
    timestamp: new Date().toISOString(),
  });
}

export async function GET() {
  // Return mock alert history
  return Response.json({
    alerts: [
      {
        id: "a1",
        contactName: "Sarah Miller",
        type: "stress_alert",
        message: "Stress alert sent: Your friend needs support right now.",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: "a2",
        contactName: "James Lee",
        type: "calm_message",
        message: "Calm message received: Take a deep breath, you've got this!",
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: "a3",
        contactName: "Alex Chen",
        type: "quick_call",
        message: "Quick call initiated for emotional support.",
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      },
    ],
  });
}

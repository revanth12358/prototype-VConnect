import { ChatAIContent } from "@/components/dashboard/chat-ai-content";

export default function ChatAIPage() {
  return <ChatAIContent />;
}

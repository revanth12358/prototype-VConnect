import { ContactsContent } from "@/components/contacts/contacts-content";

export default function ContactsPage() {
  return <ContactsContent />;
}

export interface Contact {
  id: string;
  name: string;
  initials: string;
  phone: string;
  platform: "whatsapp" | "instagram" | "sms";
  isTrusted: boolean;
  isRestricted: boolean;
  restrictedUntil?: number;
}

export interface AlertLog {
  id: string;
  contactId: string;
  contactName: string;
  type: "stress_alert" | "calm_message" | "quick_call";
  message: string;
  timestamp: string;
}

export interface MessageLog {
  id: string;
  contactName: string;
  platform: "whatsapp" | "instagram" | "sms";
  text: string;
  timestamp: string;
  isAutoReply: boolean;
}

export const MOCK_CONTACTS: Contact[] = [
  { id: "1", name: "Sarah Miller", initials: "SM", phone: "+1 555-0123", platform: "whatsapp", isTrusted: true, isRestricted: false },
  { id: "2", name: "James Lee", initials: "JL", phone: "+1 555-0456", platform: "instagram", isTrusted: true, isRestricted: false },
  { id: "3", name: "Priya Patel", initials: "PP", phone: "+1 555-0789", platform: "sms", isTrusted: false, isRestricted: false },
  { id: "4", name: "Alex Chen", initials: "AC", phone: "+1 555-0321", platform: "whatsapp", isTrusted: true, isRestricted: false },
  { id: "5", name: "Maria Garcia", initials: "MG", phone: "+1 555-0654", platform: "instagram", isTrusted: false, isRestricted: false },
  { id: "6", name: "David Kim", initials: "DK", phone: "+1 555-0987", platform: "sms", isTrusted: false, isRestricted: false },
];

export const MOCK_ALERT_LOGS: AlertLog[] = [
  { id: "a1", contactId: "1", contactName: "Sarah Miller", type: "stress_alert", message: "Stress alert sent: Your friend needs support right now.", timestamp: "2 hours ago" },
  { id: "a2", contactId: "2", contactName: "James Lee", type: "calm_message", message: "Calm message received: Take a deep breath, you've got this!", timestamp: "3 hours ago" },
  { id: "a3", contactId: "4", contactName: "Alex Chen", type: "quick_call", message: "Quick call initiated for emotional support.", timestamp: "Yesterday" },
  { id: "a4", contactId: "1", contactName: "Sarah Miller", type: "calm_message", message: "I'm here for you. Let's talk when you're ready.", timestamp: "Yesterday" },
];

export const MOCK_MESSAGE_LOGS: MessageLog[] = [
  { id: "m1", contactName: "Priya Patel", platform: "sms", text: "Hey, are you free to chat?", timestamp: "10:32 AM", isAutoReply: false },
  { id: "m2", contactName: "You", platform: "sms", text: "I'm taking some time for myself right now. I'll get back to you soon!", timestamp: "10:32 AM", isAutoReply: true },
  { id: "m3", contactName: "Maria Garcia", platform: "instagram", text: "Can we discuss the project?", timestamp: "9:15 AM", isAutoReply: false },
  { id: "m4", contactName: "You", platform: "instagram", text: "I'm in focus mode at the moment. Will reply when available.", timestamp: "9:15 AM", isAutoReply: true },
  { id: "m5", contactName: "David Kim", platform: "whatsapp", text: "Just checking in!", timestamp: "Yesterday", isAutoReply: false },
];

export const MOCK_DEVICES = [
  { id: "d1", name: "Apple Watch Series 9", type: "smartwatch", connected: true },
  { id: "d2", name: "Fitbit Charge 6", type: "fitness_band", connected: false },
  { id: "d3", name: "Oura Ring Gen 3", type: "smart_ring", connected: false },
];

export const MOCK_PLATFORMS = [
  { id: "p1", name: "WhatsApp", connected: true, icon: "MessageCircle" },
  { id: "p2", name: "Instagram", connected: true, icon: "Instagram" },
  { id: "p3", name: "SMS", connected: true, icon: "Smartphone" },
];

export interface ConnectedApp {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  color: string;
  bgColor: string;
  features: string[];
}

export const MOCK_APPS: ConnectedApp[] = [
  {
    id: "app-whatsapp",
    name: "WhatsApp",
    description: "Send auto-replies & analyze messages",
    connected: true,
    color: "#25D366",
    bgColor: "rgba(37,211,102,0.1)",
    features: ["Auto-reply", "Busy mode", "Tone analysis"],
  },
  {
    id: "app-instagram",
    name: "Instagram",
    description: "Manage DMs with AI clarity",
    connected: true,
    color: "#E1306C",
    bgColor: "rgba(225,48,108,0.1)",
    features: ["Auto-reply", "Tone analysis"],
  },
  {
    id: "app-messages",
    name: "Messages",
    description: "iMessage & SMS integration",
    connected: false,
    color: "#34C759",
    bgColor: "rgba(52,199,89,0.1)",
    features: ["Auto-reply", "Busy mode", "Tone analysis"],
  },
  {
    id: "app-telegram",
    name: "Telegram",
    description: "Bot-powered auto-replies",
    connected: false,
    color: "#0088CC",
    bgColor: "rgba(0,136,204,0.1)",
    features: ["Auto-reply", "Busy mode"],
  },
  {
    id: "app-slack",
    name: "Slack",
    description: "Workspace status & auto-respond",
    connected: false,
    color: "#E01E5A",
    bgColor: "rgba(224,30,90,0.1)",
    features: ["Auto-reply", "Busy mode", "Status sync"],
  },
  {
    id: "app-signal",
    name: "Signal",
    description: "Private messaging integration",
    connected: false,
    color: "#3A76F0",
    bgColor: "rgba(58,118,240,0.1)",
    features: ["Auto-reply", "Tone analysis"],
  },
];

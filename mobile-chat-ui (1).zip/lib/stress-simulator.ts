"use client";

// Simulated biometric data generator
export function generateStressData() {
  const baseHR = 72;
  const variance = Math.random() * 40 - 10;
  const heartRate = Math.round(baseHR + variance);

  let stressLevel: "Low" | "Moderate" | "High";
  let stressScore: number;

  if (heartRate < 80) {
    stressScore = Math.round(20 + Math.random() * 15);
    stressLevel = "Low";
  } else if (heartRate < 95) {
    stressScore = Math.round(40 + Math.random() * 25);
    stressLevel = "Moderate";
  } else {
    stressScore = Math.round(70 + Math.random() * 25);
    stressLevel = "High";
  }

  stressScore = Math.min(100, Math.max(0, stressScore));

  return {
    heartRate,
    stressScore,
    stressLevel,
    hrv: Math.round(40 + Math.random() * 30),
    respiratoryRate: Math.round(14 + Math.random() * 6),
    skinTemp: +(97 + Math.random() * 2).toFixed(1),
  };
}

export function getStressColor(level: "Low" | "Moderate" | "High") {
  switch (level) {
    case "Low":
      return "text-primary";
    case "Moderate":
      return "text-accent";
    case "High":
      return "text-destructive";
  }
}

export function getStressBgColor(level: "Low" | "Moderate" | "High") {
  switch (level) {
    case "Low":
      return "bg-primary/15";
    case "Moderate":
      return "bg-accent/15";
    case "High":
      return "bg-destructive/15";
  }
}

export function getStressRingColor(level: "Low" | "Moderate" | "High") {
  switch (level) {
    case "Low":
      return "stroke-primary";
    case "Moderate":
      return "stroke-accent";
    case "High":
      return "stroke-destructive";
  }
}
